# inside of __init__.py
from PathManager import ShiftFilePath